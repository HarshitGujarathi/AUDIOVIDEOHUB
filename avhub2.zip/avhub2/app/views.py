from django.shortcuts import render
import os
# import ffmpeg
from moviepy.editor import VideoFileClip
from .models import Video

def demo(request):        # function to show all details of videp
    # storing all details of Video database
    objVid = Video.objects.all()
    return render(request,'demo.html',{'objVid':objVid})

def video(request):                 # function to store the data
    if request.method == 'POST' and request.FILES['vfile']:
        video = request.FILES['vfile']

        # Save the video file to a temporary location
        video_path ='D:/avhub2/media/videos/video.mp4'
        with open(video_path, 'wb') as destination:
            for chunk in video.chunks():
                destination.write(chunk)

        # Extract audio from the video
        audio_path ='D:/avhub2/media/temporary/audio.mp3'
        video_clip = VideoFileClip(video_path)
        audio_clip = video_clip.audio
        audio_clip.write_audiofile(audio_path)

        # Save the video object with the audio path
        video_obj = Video(name=request.POST['vname'] ,videofile=video, audiofile=audio_path)
        video_obj.save()
       
        # Close the video and audio clips
        video_clip.close()
        audio_clip.close()

        # Delete the temporary video file
        os.remove(video_path)
        return render(request,'demo.html')

